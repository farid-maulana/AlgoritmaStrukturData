package Tugas;

/**
 *
 * @author FARLAN
 */
public class Mahasiswa {
    String nama;
    int nilai;
}
